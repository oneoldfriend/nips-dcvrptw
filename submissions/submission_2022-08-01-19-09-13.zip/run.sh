#!/bin/bash
python solver.py --verbose