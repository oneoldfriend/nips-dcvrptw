#!/bin/bash
python solver.py --verbose --model gnn_64_2_mean_greedy_greedy_0.5_nr_99