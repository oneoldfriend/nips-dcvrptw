from ._strategies import STRATEGIES, _filter_instance  # noqa
